package com.example.medicaladvisorapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class HealthTip extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);






    }
}