package com.example.medicaladvisorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class Dashboard extends AppCompatActivity {
    TextView tRemedy,tTips,tReminder,tMaps;
    ImageView imgRemedy,imgTips,imgReminder,imgMaps;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard2);
        tRemedy=(TextView)findViewById(R.id.textRemedy);
        tTips=(TextView)findViewById(R.id.textTips);
        tReminder=(TextView)findViewById(R.id.textReminder);
        tMaps=(TextView)findViewById(R.id.textMaps);

        imgRemedy=(ImageView)findViewById(R.id.imageRemedies);
        imgTips=(ImageView)findViewById(R.id.imageTips);
        imgReminder=(ImageView)findViewById(R.id.imageReminder);
        imgMaps=(ImageView)findViewById(R.id.imageMaps);

        tRemedy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Chatbot.class));
            }
        });
        imgRemedy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Chatbot.class));
            }
        });


        tTips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),HealthDashboard.class));
            }
        });

        imgTips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),HealthDashboard.class));
            }
        });

        tReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Todo.class));
            }
        });

        imgReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Todo.class));
            }
        });
        tMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MapsFragment.class));
            }
        });

        imgMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MapsFragment.class));
            }
        });

    }

    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();//logout
        startActivity(new Intent(getApplicationContext(), LoginMedi.class));
        finish();
    }
    }
