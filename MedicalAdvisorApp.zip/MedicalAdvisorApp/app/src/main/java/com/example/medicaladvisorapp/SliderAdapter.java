package com.example.medicaladvisorapp;

import android.content.Context;
import android.graphics.Color;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.airbnb.lottie.model.content.ShapeTrimPath;

public class SliderAdapter extends PagerAdapter {

    Context context;
    LayoutInflater layoutInflater;
    public SliderAdapter(Context context){

        this.context=context;
    }
    //Arrays
    public int[] images={R.drawable.burn, R.drawable.hypothermia, R.drawable.heat, R.drawable.sprain,R.drawable.shock};

    public String [] titleArray={"BURN", "HYPOTHERMIA","HEAT EXHAUSTION","SPRAIN","SHOCK"};

    public String[] descriptionArray={"1.Run cool water over the afflicted area (avoid icy or very cold water).\n\n2.Don’t break any blisters.\n\n3.Apply moisturizer over the area, like aloe vera.",
            "1.Cover the person with blankets and use heat packs.\n\n2.Move the person out of the cold, and remove any wet clothing.\n\n3.Give the person warm fluids.",
            "1.Get the person to a shaded area that’s out of the sun.\n\n2.Give the person water and keep them hydrated.\n\n3.Place a cool cloth on their forehead to lower their body temperature.",
            "1.Keep the injured limb elevated.\n\n2.Ice for a while. Then compress. Repeat at intervals.\n\n3.Keep the injured area compressed.Don’t wrap it too tight that it’ll cut off circulation.",
            "1.Lay the person down and elevate the legs and feet slightly.\n\n2.Don't let the person eat or drink anything.\n\n3.Loosen tight clothing and, if needed, cover the person with a blanket to prevent chilling."};

    public int[] backgroundColorArray={Color.rgb(30,144,255), Color.rgb(239,85,85),Color.rgb(110,49,89),Color.rgb(1,188,212)};

    @Override
    public int getCount() {
        return titleArray.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull  View view, @NonNull  Object object) {
        return view==(LinearLayout)object;
    }

    @NonNull

    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        layoutInflater=(LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view=layoutInflater.inflate(R.layout.slide_layout,container,false);

        LinearLayout linearLayout=(LinearLayout)view.findViewById(R.id.LL);
        ImageView imageView=(ImageView) view.findViewById(R.id.slideImage);
        TextView t1_title=(TextView) view.findViewById(R.id.textHeading);
        TextView t2_desc=(TextView) view.findViewById(R.id.textDescription);

        linearLayout.setBackgroundColor(backgroundColorArray[position]);
        imageView.setImageResource(images[position]);
        t1_title.setText(titleArray[position]);
        t2_desc.setText(descriptionArray[position]);


        container.addView(view);


        return view;
    }
    public void destroyItem(ViewGroup container,int position,Object object){
        container.removeView((LinearLayout)object);
    }
}
