package com.example.medicaladvisorapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.medicaladvisorapp.Guidelines;
import com.example.medicaladvisorapp.LoginMedi;
import com.example.medicaladvisorapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SignupMedi extends AppCompatActivity {

        EditText fullname,temail,password,phone;
        Button signup;
        TextView logintext;
        FirebaseAuth fAuth;
        ProgressBar progressBar;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_signup_and_login);
            fullname=findViewById(R.id.Name);
            temail=findViewById(R.id.email_signup);
            password=findViewById(R.id.password_signup);
            phone=findViewById(R.id.PhoneNumber);
            signup=findViewById(R.id.buttonSignup);


            fAuth=FirebaseAuth.getInstance();
            progressBar=findViewById(R.id.progressBarSignup);

            if(fAuth.getCurrentUser()!= null){
                //Intent it=new Intent(SignupMedi.this,Guidelines.class);
                startActivity(new Intent(getApplicationContext(),LoginMedi.class));
                finish();
            }



            signup.setOnClickListener(v -> {
                String email=temail.getText().toString().trim();
                String pwd=password.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    temail.setError("Email is Required.");
                    return;
                }
                if(TextUtils.isEmpty(pwd)){
                    password.setError("Password is Required.");
                    return;
                }
                if(pwd.length()<6){
                    password.setError("Password MUST be >= 6 characters");
                }
                if(phone.length()<10){
                    phone.setError("Phone number can not be less than 10 digits");
                }

                progressBar.setVisibility(View.VISIBLE);

                //register the user in firebase

                fAuth.createUserWithEmailAndPassword(email,pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){
                            // Intent it=new Intent(SignupMedi.this,Guidelines.class);
                            Toast.makeText(SignupMedi.this,"User Created",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),LoginMedi.class));


                        }else{
                            Toast.makeText(SignupMedi.this,"Error! "+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });

            });
            logintext=(TextView)findViewById(R.id.loginText);
            logintext.setOnClickListener(v -> {

                startActivity(new Intent(getApplicationContext(), LoginMedi.class));

            });





        }
    }












