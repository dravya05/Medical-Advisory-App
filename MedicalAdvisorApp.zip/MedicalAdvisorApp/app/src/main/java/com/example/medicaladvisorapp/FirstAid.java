package com.example.medicaladvisorapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class FirstAid extends AppCompatActivity {
     ViewPager nSlideViewPager;


     SliderAdapter sliderAdapter;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_aid);

        nSlideViewPager=(ViewPager)findViewById(R.id.slideViewPager);
        sliderAdapter=new SliderAdapter(this);
        nSlideViewPager.setAdapter(sliderAdapter);

    }



}