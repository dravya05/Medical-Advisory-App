package com.example.medicaladvisorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Remedy extends AppCompatActivity {
    TextView remedy;
    TextView symptom;
    TextView medicalAid;

    String  s;
    String []s1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remedy);

        symptom=findViewById(R.id.textViewWhatSymptom);
        remedy=findViewById(R.id.textViewHomeRemedy);
        medicalAid=findViewById(R.id.textViewMedicalAid);

        s=getIntent().getExtras().getString("symptom");
        s1=s.split(",");

        //COVID-19
        if(s1[0].equalsIgnoreCase("Fever")|| s1[1].equalsIgnoreCase("Dry cough") || s1[2].equalsIgnoreCase("Tiredness") || s1[3].equalsIgnoreCase("Shortness of breath") || s1[4].equalsIgnoreCase("Sore throat"))
        {
            symptom.setText("These seem to be the symptoms for Covid 19.");


            remedy.setText("1) Firstly, get tested for Covid-19\n2) Quarantine yourself if you have mild symptoms.\n3) Take Vitamin C tablet thrice a day after meal.\n4) Frequent Gargle and take steam which gives relief.\n5) Try proning if you face breathing difficulty.");


            medicalAid.setText("If you feel suffocation or oxygen level falls below 90, please consult the doctor immediately!No need to panic.\n Click here to find hospitals near you.");
        }


        //ASTHMA
        else if(s1[0].equalsIgnoreCase("Cough") || s1[1].equalsIgnoreCase("Tightness in the chest") || s1[2].equalsIgnoreCase("anxious") || s1[3].equalsIgnoreCase("Breathless") || s1[4].equalsIgnoreCase("Fatigue")) {
            symptom.setText("These seem to be the symptoms for Asthma");


            remedy.setText("1) Try breathing exercises.\n" +
                    " 2) Quick-acting treatments\n" +
                    " 3) Having ginger, garlic, honey\n" +
                    " 4) Acupuncture\n" +
                    " 5) Performing yoga\n ");


            medicalAid.setText("If you can’t perform your daily activities\n" +
                    " and also have a wheeze or cough that won’t go away,\n" +
                    "see your doctor right away or seek emergency medical help.\nClick here to find hospitals near you.");
        }


        //FOOD POISONING
       else if(s1[0].equalsIgnoreCase("Nausea") || s1[1].equalsIgnoreCase("Stomach cramps") || s1[2].equalsIgnoreCase("Loss of appetite") || s1[3].equalsIgnoreCase("Aching muscles") || s1[4].equalsIgnoreCase("Vomiting"))
        {
            symptom.setText("These seem to be the symptoms for Food Poisoning");


            remedy.setText(" 1) Have Fruit juice and coconut water\n" +
                    " 2) Avoid caffeine\n" +
                    " 3) Wash hands and dishes frequently in hot, soapy water\n" +
                    " 4) Hydrating with electrolytes\n");


            medicalAid.setText("If you have symptoms of severe dehydration or if you are having weak immune system. \nIf you notice blood in your vomit or stool, \nsee your doctor right away or seek emergency medical help.\n Click here to find hospitals near you.");
        }


        //Migraine
        else if(s1[0].equalsIgnoreCase("Constipation") || s1[1].equalsIgnoreCase("Mood changes") || s1[2].equalsIgnoreCase("Food cravings") || s1[3].equalsIgnoreCase("Neck stiffness"))
        {
            symptom.setText("These seem to be the symptoms for Migraine");


            remedy.setText("1) Give a gentle massage to the temples with lavender oil.\n" +
                    "2) Have Ginger tea\n" +
                    "3) Have almonds, sunflower seeds, or magnesium-rich food in your diet.\n");


            medicalAid.setText("If you suffer from a severe headache like a thunderclap with fever.\n" +
                    "If you feel numbness or double vision,\nsee your doctor right away or seek emergency medical help.\n Click hereto find hospitals near you.");
        }


        //Dehydration
        else if(s1[0].equalsIgnoreCase("Dark urine")||s1[1].equalsIgnoreCase("dizziness")|| s1[2].equalsIgnoreCase("exhaustion")||s1[3].equalsIgnoreCase("Extreme thirst"))
        {
            symptom.setText("These seem to be symptoms for Migraine");


            remedy.setText("1)  drink about eight 8-ounce glasses of water every day.\n" +
                    "\n" + "2) If you’re dehydrated because of a condition like diarrhea, drink plenty of water until the episode passes.\n" +
                    "3) Drinking water or drinking beverages with extra electrolytes can help keep you hydrated and replace the electrolytes lost to diarrhea, too.\n");


            medicalAid.setText("If you can’t keep water down, \nsee your doctor right away or seek emergency medical help.\n Click here to find hospitals near you.");
        }
        medicalAid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Remedy.this,MapsFragment.class));
            }
        });
    }
}