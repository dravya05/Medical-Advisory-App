package com.example.medicaladvisorapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

import java.util.ArrayList;

public class Tips extends AppCompatActivity {
    private ArrayList<Item> items=new ArrayList<Item>(){};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips);


        RecyclerView recyclerView = findViewById(R.id.rView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new Adapter(items,this));


        items.add(new Item(R.drawable.one,getString(R.string.Tip1),getString(R.string.Tip1_desc)));
        items.add(new Item(R.drawable.two,getString(R.string.Tip2),getString(R.string.Tip2_desc)));
        items.add(new Item(R.drawable.six,getString(R.string.Tip3),getString(R.string.Tip3_desc)));
        items.add(new Item(R.drawable.seven,getString(R.string.Tip4),getString(R.string.Tip4_desc)));
        items.add(new Item(R.drawable.eight,getString(R.string.Tip5),getString(R.string.Tip5_desc)));
        items.add(new Item(R.drawable.nine,getString(R.string.Tip6),getString(R.string.Tip6_desc)));

    }
}