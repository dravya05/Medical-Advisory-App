package com.example.medicaladvisorapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Chat extends AppCompatActivity {
    EditText symptom;
    Button chat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat);
        symptom=findViewById(R.id.EditTextSymptom);
        chat=findViewById(R.id.buttonChatSubmit);
        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Chat.this,Remedy.class);
                String  s=symptom.getText().toString();
                i.putExtra("symptom",s);
                startActivity(i);
            }
        });
    }
}
