package com.example.medicaladvisorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class HealthDashboard extends AppCompatActivity {
    TextView textHealth,textFirst;
    ImageView imgHealth,imgFirst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_dashboard);

        textHealth=findViewById(R.id.textHealthTips);
        textFirst=findViewById(R.id.textFirstAid);
        imgHealth=findViewById(R.id.healthTips);
        imgFirst=findViewById(R.id.FirstAid);

        textHealth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Tips.class));
            }
        });
        imgHealth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Tips.class));
            }
        });
        textFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),FirstAid.class));
            }
        });
        imgFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),FirstAid.class));
            }
        });



    }
}