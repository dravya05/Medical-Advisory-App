package com.example.medicaladvisorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView wel,medi;
    private static int Splash_timeout=5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wel=findViewById(R.id.text_Welcome);
        medi=findViewById(R.id.text_MediApp);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                Intent splashIntent=new Intent(MainActivity.this,SignupMedi.class);
                startActivity(splashIntent);
                finish();

            }
        },Splash_timeout);
        Animation myanimation= AnimationUtils.loadAnimation(MainActivity.this,R.anim.animation2);
        wel.startAnimation(myanimation);
        Animation myanimation2= AnimationUtils.loadAnimation(MainActivity.this,R.anim.animationlogo);
        medi.startAnimation(myanimation);

    }
}