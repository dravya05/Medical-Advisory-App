package com.example.medicaladvisorapp;



public class Item {
    private int imageResource;
    private String Title;
    private String desc;
    private boolean isShrink=true;

    public Item() {
    }

    public Item(int imageResource, String title, String desc) {
        this.imageResource = imageResource;
        Title = title;
        this.desc = desc;
    }

    public int getImageResource() {
        return imageResource;
    }

    public void setImageResource(int imageResource) {
        this.imageResource = imageResource;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public boolean isShrink() {
        return isShrink;
    }

    public void setShrink(boolean shrink) {
        isShrink = shrink;
    }
}
